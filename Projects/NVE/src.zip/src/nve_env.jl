module nve_env

greet() = print("Hello World!")

end 
